@file:OptIn(ExperimentalMaterial3Api::class)

package com.hisab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.rememberDatePickerState
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.PaddingValues
import com.hisab.app.data.fmtDate
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hisab.app.HisabViewModel
import com.hisab.app.data.Account
import com.hisab.app.data.Txn

private val GREEN = Color(0xFF2E7D32)
private val RED = Color(0xFFC62828)

/** আয়-ব্যয়ের তালিকা, খাত অনুযায়ী ফিল্টার ও ট্রান্সফার */
@Composable
fun TransactionsScreen(vm: HisabViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    var showTransfer by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var showCats by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Txn?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(vm.filter ?: "") },
                actions = {
                    IconButton(onClick = { showCats = true }) {
                        Icon(Icons.Default.Category, contentDescription = "খাত")
                    }
                    IconButton(onClick = { showTransfer = true }) {
                        Icon(Icons.Default.CompareArrows, contentDescription = "ট্রান্সফার")
                    }
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(
                                Icons.Default.FilterList,
                                contentDescription = "খাত ফিল্টার",
                                tint = if (vm.filter != null) Color(0xFFFB8C00) else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("সব খাত") },
                                onClick = { vm.applyFilter(null); menu = false },
                            )
                            vm.usedCategories.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text(c) },
                                    onClick = { vm.applyFilter(c); menu = false },
                                )
                            }
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = "নতুন লেনদেন")
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            if (vm.txns.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("কোনো লেনদেন নেই")
                }
            } else {
                // নিচে একটু ফাঁকা রাখা হয়েছে, যাতে শেষ সারি (+) বাটন ও মোটের নিচে ঢাকা না পড়ে
                LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                    items(vm.txns, key = { it.id }) { t -> TxnRow(t) { toDelete = t } }
                }
            }
            // স্ক্রিনে যা দেখা যাচ্ছে তার নিট মোট (জমা − খরচ): নিচে বামে, ছোট ও ধূসর
            val net = vm.txns.sumOf { if (it.type == "credit") it.amount else -it.amount }
            Text(
                "মোট: ${tk(net)}",
                modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 16.dp),
                fontSize = 12.sp,
                color = Color.Gray,
            )
        }
    }

    if (showAdd) {
        AddTxnDialog(
            accounts = vm.accounts,
            expenseCats = vm.categories.filter { it.kind == "expense" }.map { it.name },
            incomeCats = vm.categories.filter { it.kind == "income" }.map { it.name },
            onDismiss = { showAdd = false },
            onSave = { type, splits, cat, note, baki, date ->
                // তালিকায় না থাকা নতুন খাত লিখলে নিজে থেকে সেভ হয়ে যায়
                vm.addCategory(cat, if (type == "debit") "expense" else "income")
                if (baki) vm.addBakiExpense(splits.sumOf { it.second }, cat, note, date)
                else vm.addTxns(type, splits, cat, note, date)
                showAdd = false
            },
        )
    }
    if (showCats) {
        CategoriesDialog(
            categories = vm.categories,
            onAdd = { name, kind -> vm.addCategory(name, kind) },
            onRename = { id, name -> vm.renameCategory(id, name) },
            onDelete = { id -> vm.deleteCategory(id) },
            onDismiss = { showCats = false },
        )
    }
    if (showTransfer) {
        TransferDialog(
            accounts = vm.accounts,
            onDismiss = { showTransfer = false },
            onSave = { from, to, amount ->
                vm.transfer(from, to, amount)
                showTransfer = false
            },
        )
    }
    toDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("লেনদেন মুছবেন?") },
            text = { Text("${t.category} • ${tk(t.amount)}\nঅ্যাকাউন্টের ব্যালেন্স সেই অনুযায়ী ঠিক হয়ে যাবে।") },
            confirmButton = {
                TextButton(onClick = { vm.deleteTxn(t.id); toDelete = null }) { Text("মুছুন") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("বাতিল") } },
        )
    }
}

@Composable
private fun TxnRow(t: Txn, onDelete: () -> Unit) {
    val credit = t.type == "credit"
    val color = if (credit) GREEN else RED
    ListItem(
        leadingContent = {
            Icon(
                if (credit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                contentDescription = null,
                tint = color,
            )
        },
        headlineContent = { Text(t.category) },
        supportingContent = {
            val note = if (t.note.isNotBlank()) " • ${t.note}" else ""
            Text("${t.account.ifEmpty { "অন্যান্য" }} • ${fmtDate(t.date)}$note")
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    (if (credit) "+" else "-") + tk(t.amount),
                    color = color,
                    fontWeight = FontWeight.Bold,
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "মুছুন")
                }
            }
        },
    )
}

@Composable
private fun AddTxnDialog(
    accounts: List<Account>,
    expenseCats: List<String>,
    incomeCats: List<String>,
    onDismiss: () -> Unit,
    onSave: (type: String, splits: List<Pair<Long?, Double>>, category: String, note: String, baki: Boolean, date: LocalDate) -> Unit,
) {
    val ctx = LocalContext.current
    var type by remember { mutableStateOf("debit") }
    var lines by remember { mutableStateOf(listOf(SplitLine())) }
    var cat by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var baki by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var pickDate by remember { mutableStateOf(false) }

    FormDialog(
        title = "নতুন লেনদেন",
        confirmText = "সংরক্ষণ",
        onDismiss = onDismiss,
        onConfirm = {
            val c = cat.trim()
            val isBaki = type == "debit" && baki
            val splits = lines.splits()
            if (splits.isEmpty()) {
                ctx.toast("টাকার পরিমাণ দিন")
            } else if (c.isEmpty()) {
                ctx.toast("খাত দিন")
            } else {
                // অ্যাকাউন্ট না বাছলে লেনদেনটা "অন্যান্য" হিসেবে সেভ হয়
                onSave(type, splits.map { it.first?.id to it.second }, c, note.trim(), isBaki, date)
            }
        },
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = type == "debit",
                onClick = { type = "debit"; cat = ""; lines = lines.map { it.copy(acc = null) } },
                label = { Text("খরচ") },
            )
            FilterChip(
                selected = type == "credit",
                onClick = { type = "credit"; cat = ""; baki = false; lines = lines.map { it.copy(acc = null) } },
                label = { Text("আয়") },
            )
        }
        if (type == "debit" && baki) {
            // বাকি খরচে অ্যাকাউন্ট থেকে টাকা কাটে না, তাই শুধু পরিমাণ
            MoneyField(lines.first().amount) { v -> lines = listOf(lines.first().copy(acc = null, amount = v)) }
        } else {
            SplitLines(
                // খরচের সময় ০ ব্যালেন্সের অ্যাকাউন্ট দেখানো হয় না
                accounts = if (type == "debit") accounts.withMoney() else accounts,
                lines = lines,
                onChange = { lines = it },
                accountLabel = if (type == "debit") "অ্যাকাউন্ট থেকে কাটবে" else "অ্যাকাউন্টে জমা হবে",
            )
        }
        CategoryField(if (type == "debit") expenseCats else incomeCats, cat) { cat = it }
        if (type == "debit") {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("বাকি (এখনো টাকা দিইনি)")
                Switch(checked = baki, onCheckedChange = { baki = it })
            }
        }
        TextInput(note, { note = it }, "নোট")
        // সবার নিচে: আজকের তারিখ দেখায়, চাপলে আগের তারিখ বাছা যায়
        OutlinedButton(onClick = { pickDate = true }, modifier = Modifier.fillMaxWidth()) {
            Text("তারিখ: ${fmtDate(date.toString())}")
        }
    }

    if (pickDate) {
        // আজকের পরের তারিখ বাছা যায় না
        val todayUtc = LocalDate.now().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val state = rememberDatePickerState(
            initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis <= todayUtc
                override fun isSelectableYear(year: Int): Boolean = year <= LocalDate.now().year
            },
        )
        DatePickerDialog(
            onDismissRequest = { pickDate = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        date = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                    }
                    pickDate = false
                }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton(onClick = { pickDate = false }) { Text("বাতিল") } },
        ) {
            DatePicker(state = state)
        }
    }
}

@Composable
private fun TransferDialog(
    accounts: List<Account>,
    onDismiss: () -> Unit,
    onSave: (from: Long, to: Long, amount: Double) -> Unit,
) {
    val ctx = LocalContext.current
    var from by remember { mutableStateOf<Account?>(null) }
    var to by remember { mutableStateOf<Account?>(null) }
    var amount by remember { mutableStateOf("") }

    FormDialog(
        title = "ট্রান্সফার (যেমন: ব্যাংক থেকে DPS)",
        confirmText = "ট্রান্সফার",
        onDismiss = onDismiss,
        onConfirm = {
            val a = amount.toDoubleOrNull()
            val f = from
            val t = to
            if (a == null || a <= 0 || f == null || t == null || f.id == t.id) {
                ctx.toast("সঠিক তথ্য দিন (দুটি আলাদা অ্যাকাউন্ট লাগবে)")
            } else {
                onSave(f.id, t.id, a)
            }
        },
    ) {
        val label: (Account) -> String = { "${it.name} (${tk(it.balance)})" }
        Picker("যে অ্যাকাউন্ট থেকে", accounts.withMoney(), from, label) { from = it }
        Picker("যে অ্যাকাউন্টে", accounts, to, label) { to = it }
        MoneyField(amount) { amount = it }
    }
}
